document.addEventListener("DOMContentLoaded", function() {
    window.addEventListener("load", function() {
        var preloader = document.querySelector(".preloader-orbit-loading");
        preloader.style.display = "none";
    });
});
