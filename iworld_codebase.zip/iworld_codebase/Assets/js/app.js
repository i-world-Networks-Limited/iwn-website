$(document).ready(function () {
    $('.home-header-slide-container').slidejs({
      start: 1, // Start with the first slide
      time: 5000, // Time between slides in milliseconds (adjust as needed)
      auto: true, // Auto play the carousel
    });
  });

// Recaptcha
// Submit Buttons for forms


