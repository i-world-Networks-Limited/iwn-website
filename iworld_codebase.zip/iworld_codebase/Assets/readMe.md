The header size is 1440 x 1184
Graphics for contact us page
Graphics for the certification section and the about us section
Graphics on the careers, internet for home, internet for business and MPLS
Graphics for MSP: Education, Small and Medium Business and Enterprise, KYC for home internet page and KYC for Business internet page
Contact, About, Careers, sign up page would be in portrait size


IWN BRAND COLORS
Orange => R: 245 G: 140 B: 41 (#F58C29) 
Orange => R: 255 G: 102 B: 0 (#Ff6600)    
Green => R: 92 G: 198 B: 64 (#5CC640) 
Green => R: 89 G: 175 B: 23 (#59AF17)    
Black => R: 50% BLACK (#808080) 
Black => R: 70% BLACK (#4D4D4D) 
BLACK (#000000)
WHITE (#FFFFFF)